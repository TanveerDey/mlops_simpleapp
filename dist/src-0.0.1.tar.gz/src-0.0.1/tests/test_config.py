def test_generic():
    a = 40
    b = 50

    assert a != b
